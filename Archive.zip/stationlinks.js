"use strict";

var stationDict = {}

stationDict["shalom haiti"] = "https://s3.amazonaws.com/zenoradioalexa/specificstations/shalomhaiti.m3u";

module.exports = stationDict;

