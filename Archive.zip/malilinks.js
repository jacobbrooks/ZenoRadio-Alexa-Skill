"use strict";

var maliDict = {};

maliDict["music"] = "https://s3.amazonaws.com/zenoradioalexa/malistreams/music.pls";
maliDict["general"] = "https://s3.amazonaws.com/zenoradioalexa/malistreams/general.pls";
maliDict["religion"] = "https://s3.amazonaws.com/zenoradioalexa/malistreams/religion.pls";
maliDict["french"] = "https://s3.amazonaws.com/zenoradioalexa/malistreams/french.pls";
maliDict["sports"] = "https://s3.amazonaws.com/zenoradioalexa/malistreams/sports.m3u";

module.exports = maliDict;