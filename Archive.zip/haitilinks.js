"use strict";

var haitiDict = {};

haitiDict["music"] = "https://s3.amazonaws.com/zenoradioalexa/haitistreams/pop.m3u";
haitiDict["pop"] = "https://s3.amazonaws.com/zenoradioalexa/haitistreams/pop.m3u";
haitiDict["christian"] = "https://s3.amazonaws.com/zenoradioalexa/haitistreams/christian.m3u";
haitiDict["news"] = "https://s3.amazonaws.com/zenoradioalexa/haitistreams/news.m3u";
haitiDict["international"] = "https://s3.amazonaws.com/zenoradioalexa/haitistreams/international.m3u";
haitiDict["gospel"] = "https://s3.amazonaws.com/zenoradioalexa/haitistreams/gospel.m3u";
haitiDict["creole"] = "https://s3.amazonaws.com/zenoradioalexa/haitistreams/creole.m3u";
haitiDict["talk"] = "https://s3.amazonaws.com/zenoradioalexa/haitistreams/talk.m3u";

module.exports = haitiDict;

