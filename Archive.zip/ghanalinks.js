"use strict";

var ghanaDict = {};

ghanaDict["music"] = "https://s3.amazonaws.com/zenoradioalexa/ghanastreams/music.m3u";
ghanaDict["pop"] = "https://s3.amazonaws.com/zenoradioalexa/ghanastreams/pop.m3u";
ghanaDict["christian"] = "https://s3.amazonaws.com/zenoradioalexa/ghanastreams/christian.m3u";
ghanaDict["news"] = "https://s3.amazonaws.com/zenoradioalexa/ghanastreams/news.m3u";
ghanaDict["international"] = "https://s3.amazonaws.com/zenoradioalexa/ghanastreams/international.m3u";
ghanaDict["gospel"] = "https://s3.amazonaws.com/zenoradioalexa/ghanastreams/gospel.m3u";
ghanaDict["talk"] = "https://s3.amazonaws.com/zenoradioalexa/ghanastreams/talk.m3u";

module.exports = ghanaDict;